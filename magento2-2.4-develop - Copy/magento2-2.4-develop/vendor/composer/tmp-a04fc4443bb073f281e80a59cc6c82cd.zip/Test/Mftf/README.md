# Theme Functional Tests

The Functional Test Module for **Magento Theme** module.
