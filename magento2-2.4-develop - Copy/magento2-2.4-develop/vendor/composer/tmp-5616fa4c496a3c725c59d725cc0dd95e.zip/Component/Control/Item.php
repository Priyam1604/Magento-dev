<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Ui\Component\Control;

use Magento\Framework\DataObject;

/**
 * Class Item
 */
class Item extends DataObject
{
    //
}
