# Backend Functional Tests

The Functional Test Module for **Magento Backend** module.
