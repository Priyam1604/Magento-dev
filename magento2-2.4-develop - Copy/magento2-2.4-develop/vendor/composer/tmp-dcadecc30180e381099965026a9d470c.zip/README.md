# Directory

**Directory** enables the management of countries and regions recognized by the store and associated data
like the country code and currency rates. Also, enables conversion of prices to a specified currency format.
