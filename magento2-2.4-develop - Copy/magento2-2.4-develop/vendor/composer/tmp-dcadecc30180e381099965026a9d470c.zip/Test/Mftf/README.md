# Directory Functional Tests

The Functional Test Module for **Magento Directory** module.
